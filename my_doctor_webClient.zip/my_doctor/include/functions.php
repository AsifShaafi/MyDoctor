<?php

function confirmQuery($result_set)
{
    if (!$result_set) {
        die("Database query failed"
            . mysqli_connect_error()
            . " ( "
            . mysqli_connect_errno()
        . " )");
    }
}

function safeString($username)
{
    global $connection;

    $username = trim($username);

    return mysqli_real_escape_string($connection, $username);
}

function getDoctorByUsername($username)
{
    $username = trim($username);

    global $connection;

    $query = "SELECT * FROM doctors WHERE user_name = '{$username}' LIMIT 1";

    $result = mysqli_query($connection, $query);
    confirmQuery($result);

    if ($result != null) {
        # code...
        $doctor = mysqli_fetch_assoc($result);
        return $doctor;
    }
    return $result;
}

function getPatientByUsername($username)
{
    $username = trim($username);

    global $connection;

    $query = "SELECT * FROM patients WHERE username = '{$username}' LIMIT 1";

    $result = mysqli_query($connection, $query);
    confirmQuery($result);

    if ($result != null) {
        # code...
        $patient = mysqli_fetch_assoc($result);
        return $patient;
    }
    return $result;
}

function getPatientList($username)
{
    global $connection;

    $username = safeString($username);

    $result_set = getDoctorByUsername($username);

    $doctor_username = $result_set['user_name'];

    $query = "SELECT * FROM doctor_patient_list WHERE doctor_username = '{$username}'";

    $result_set = mysqli_query($connection, $query);

    confirmQuery($result_set);

    $patient_list = array();

    if ($result_set) {
        // while ($patient = mysqli_fetch_assoc($result_set))
        // {
        //     $patient_list[] = $patient['patient_name'];
        // }
        //
        // $jsonArray = array("patient_list" => $patient_list);

        while ($patient = mysqli_fetch_assoc($result_set)) {

            $patient_list[] = $patient;
        }
        $jsonArray = array('patient_list' => $patient_list);

        return json_encode($jsonArray);
    } else {
        return null;
    }
}

function registerDoctor($full_name, $user_name, $password, $sector){
    $full_name = safeString($full_name);
    $user_name = safeString($user_name);
    $password = safeString($password);
    $sector = safeString($sector);

    global $connection;

    $query = "INSERT INTO doctors ( ";
    $query .= "full_name, user_name, password, sectors ";
    $query .= ") VALUES ( ";
    $query .= "'{$full_name}', '{$user_name}', '{$password}', '{$sector}' )";

    $result_set = mysqli_query($connection, $query);
    confirmQuery($result_set);

    return ($result_set && mysqli_affected_rows($connection) == 1);
}

function registerPatient($fullname, $username, $age, $image)
{
  global $connection;

  $query = "INSERT INTO patients ( ";
  $query .= "name, username, age, image ";
  $query .= ") VALUES ( ";
  $query .= "'{$fullname}', '{$username}', '{$age}' , '{$image}')";

  $result_set = mysqli_query($connection, $query);
  confirmQuery($result_set);

  return ($result_set && mysqli_affected_rows($connection) == 1);
}
