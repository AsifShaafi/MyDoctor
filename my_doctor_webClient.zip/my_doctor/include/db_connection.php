<?php
/**
 * Created by PhpStorm.
 * User: Shaafi
 * Date: 06-Jul-16
 * Time: 4:27 PM
 */

define("DB_NAME", "my_doctor");
define("DB_USER", "root");
define('DB_PASSWORD', "");
define('DB_HOST', 'localhost');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if (mysqli_connect_errno()) {
    die(
        "database connection failed "
        . mysqli_connect_error()
        . " ("
        . mysqli_connect_errno() . " ) "
    );
}
