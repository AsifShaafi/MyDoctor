<?php
/**
 * Created by PhpStorm.
 * User: Shaafi
 * Date: 06-Jul-16
 * Time: 5:07 PM
 */

require_once ("include/db_connection.php");
require_once ("include/functions.php");

if (isset($_POST['submit'])) {
  # code...
  $username = $_POST["username"];

  $result_set = getPatientByUsername($username);

  if($result_set)
  {
    $result = array('patient' => $result_set );
      echo json_encode($result);
  }
  else{
      echo "not found";
  }
}
