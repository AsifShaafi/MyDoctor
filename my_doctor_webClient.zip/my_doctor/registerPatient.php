<?php
/**
 * Created by PhpStorm.
 * User: Shaafi
 * Date: 11-Jul-16
 * Time: 2:57 AM
 */

require_once("include/db_connection.php");
require_once("include/functions.php");

if (isset($_POST['submit'])) {
    $fullname = $_POST['name'];
    $username = $_POST['username'];
    $age = $_POST['age'];

    $check = getPatientByUsername($username);

    if ($check == null)
    {
      $result = registerPatient($fullname, $username, $age);

      if ($result) {
          echo "registered";
      }
      else {
          echo "failed";
      }
    }
    else {
      echo "found";
    }
}
