<?php
/**
 * Created by PhpStorm.
 * User: Shaafi
 * Date: 11-Jul-16
 * Time: 2:57 AM
 */

require_once("include/db_connection.php");
require_once("include/functions.php");

if (isset($_POST['submit'])) {
    $full_name = $_POST['full_name'];
    $user_name = $_POST['user_name'];
    $sector = $_POST['sectors'];
    $password = $_POST['password'];
    
    $result = registerDoctor($full_name, $user_name, $password, $sector);

    if ($result) {
        echo "registered";
    }
    else {
        echo "failed";
    }
}