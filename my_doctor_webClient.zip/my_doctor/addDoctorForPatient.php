<?php

require_once ("include/db_connection.php");
require_once ("include/functions.php");

if (isset($_POST['submit'])) {
  # code...
  global $connection;

  $doctor_username = safeString($_POST['doctor_username']);
  $patient_username = safeString($_POST['patient_username']);
  $patient_name = safeString($_POST['patient_name']);
  $age = safeString($_POST['age']);

  $query = "INSERT INTO doctor_patient_list ( ";
  $query .= "doctor_username, patient_name, patient_username, age ";
  $query .= ") VALUES ( ";
  $query .= "'{$doctor_username}', '{$patient_name}', '{$patient_username}', '{$age}' )";

  $result = mysqli_query($connection, $query);
  confirmQuery($result);

  if ($result && mysqli_affected_rows($connection) == 1)
  {
    echo "inserted";
  }
  else
  {
    echo "failed";
  }

}


?>
