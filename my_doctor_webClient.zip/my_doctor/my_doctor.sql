-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2017 at 06:30 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `sectors` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `full_name`, `user_name`, `password`, `sectors`) VALUES
(1, 'Abdus Sayef', 'sayef1', 'sa', 'dentiest'),
(2, 'a', 'a', 'aa', 'asdfds'),
(10, 'a', 'aa', 'a', 'a'),
(11, 'a', 'aaa', 'a', 'a'),
(12, 'a', 'aaaa', 's', 'ghff'),
(13, 'Sayef Reyadh', 'reyadh.khan', '1234', 'Eye'),
(14, 'a', 'se', 'se', ''),
(15, 'a', 'sr', 's', ''),
(16, 'a', 'q', 'q', 'Surgery'),
(17, 'a', 'e', 'e', 'Pathology, Obstretics and Gynaecology, Physician');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_patient_list`
--

CREATE TABLE `doctor_patient_list` (
  `id` int(3) NOT NULL,
  `doctor_username` varchar(30) NOT NULL,
  `doctor_id` int(3) DEFAULT NULL,
  `patient_name` varchar(30) NOT NULL,
  `patient_username` varchar(30) NOT NULL,
  `age` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_patient_list`
--

INSERT INTO `doctor_patient_list` (`id`, `doctor_username`, `doctor_id`, `patient_name`, `patient_username`, `age`) VALUES
(1, '', 1, 'sifat', 'sifat1', '22'),
(2, '', 1, 'shaafi', 'shaafi1', '21'),
(3, 'sayef1', NULL, 'Shaafi', 'shaafi', NULL),
(4, 'sayef1', NULL, 'Shaafi', 'shaafi', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `bloodgroup` varchar(3) DEFAULT NULL,
  `birthday` varchar(15) DEFAULT NULL,
  `age` varchar(3) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`name`, `username`, `bloodgroup`, `birthday`, `age`, `image`) VALUES
('Shaafi', 'shaafi', NULL, NULL, '20', ''),
('Shaafi', 'shaafi', NULL, NULL, '20', ''),
('a', 'shaafi1', NULL, NULL, '20', ''),
('g', 'l', NULL, NULL, '1', ''),
('l', 'o', NULL, NULL, 'o', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indexes for table `doctor_patient_list`
--
ALTER TABLE `doctor_patient_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `doctor_patient_list`
--
ALTER TABLE `doctor_patient_list`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
