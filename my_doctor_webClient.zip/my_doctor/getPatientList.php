<?php
/**
 * Created by PhpStorm.
 * User: Shaafi
 * Date: 06-Jul-16
 * Time: 9:25 PM
 */

require_once("include/db_connection.php");
require_once("include/functions.php");

if(isset($_POST['submit'])) {

    $username = "";

    $result = getPatientList($_POST['username']);

    echo $result;

}
